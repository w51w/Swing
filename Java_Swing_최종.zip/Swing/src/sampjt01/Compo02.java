package sampjt01;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class Compo02 extends JFrame{
	JLabel lb;
	Container c;
	Toolkit kit;
	Dimension screenSize;
	Compo02(){
		super("TITLE");
		kit = Toolkit.getDefaultToolkit();
		screenSize = kit.getScreenSize(); //화면 !모니터! 크기
		lb = new JLabel("java");
		c = getContentPane();
		//setLayout(null) 로 정하면 위치와 크기를 사용자가 설정해야됨
		lb.setSize(50, 50); //크기 설정
		lb.setOpaque(true);
		lb.setBackground(Color.cyan);
		lb.setLocation(50, 50);
		lb.addKeyListener(new BBB());
		lb.setFocusable(true);
		c.add(lb);
		c.addMouseListener(new AAA());
		
	}
	class AAA extends MouseAdapter{ //필요없는 인터페이스 메소드를 오버라이드 할 필요가 사라짐 
		//인터페이스 메소드가 하나라면 굳이 어댑터 쓸 필요 없다
		
		@Override
		public void mousePressed(MouseEvent e) {
			lb.setLocation(e.getX(), e.getY());
		}
	}
	class BBB extends KeyAdapter{
		@Override
		public void keyPressed(KeyEvent e) {
			// TODO Auto-generated method stub
			if(e.getKeyChar() == 'q') {
				System.exit(0); //이것만 달랑 쓰면 종료 안함. 포커스가 없기 때문 lb.setFocusable(true);
			}
			if(e.getKeyCode() ==KeyEvent.VK_ENTER) {
				int r = (int) (Math.random() * 256);
				int g = (int) (Math.random() * 256);
				int b = (int) (Math.random() * 256);
				c.setBackground(new Color(r,g,b));
			}
			if(e.getKeyCode() == KeyEvent.VK_LEFT) {			
				lb.setLocation(lb.getX() - 50, lb.getY());
				if(lb.getX() < 0) 
					lb.setLocation(lb.getX() + 50, lb.getY());
			}
			if(e.getKeyCode() == KeyEvent.VK_RIGHT) {			
				lb.setLocation(lb.getX() + 50, lb.getY());
				if(lb.getX() + lb.getSize().width > screenSize.width) 
					lb.setLocation(lb.getX() - 50, lb.getY());
			}
			if(e.getKeyCode() == KeyEvent.VK_UP) {			
				lb.setLocation(lb.getX(), lb.getY() - 50);
				if(lb.getY() < 0) 
					lb.setLocation(lb.getX(), lb.getY() + 50);
			}
			if(e.getKeyCode() == KeyEvent.VK_DOWN) {			
				lb.setLocation(lb.getX(), lb.getY() + 50);
				if(lb.getY() + lb.getSize().height  > screenSize.height) 
					lb.setLocation(lb.getX() , lb.getY() - 50);
			}
		}
	}
	void display() {
		setLayout(null);
		setSize(screenSize.width, screenSize.height);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	public static void main(String[] args) {
		Compo02 c02 = new Compo02();
		c02.display();
	}

}
