package sampjt01;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Compo01 extends JFrame implements ActionListener{
	JButton close , btn, clear;
	
	Compo01(){
		super("나는 제목");
		close = new JButton("Close");
		btn = new JButton("btn");
		clear = new JButton("Clear");
	}
	void display() { //보여주는 메소
		setLayout(new FlowLayout());
		setSize(300,300);
		close.setText("funny java");
		close.addActionListener(this);
		btn.addActionListener(this);
		clear.addActionListener(this);
		add(close); add(btn); add(clear);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	/*
	class AAA implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == close) System.exit(0);
			else if (e.getSource() == btn) {
				setTitle(btn.getText());
			}
		}
	}
	*/
	public static void main(String[] args) {
		Compo01 c1 = new Compo01();
		c1.display();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == close) System.exit(0);
		
		else if(e.getSource() == btn) setTitle(btn.getText());
		else if(e.getSource() == clear) btn.setText(clear.getText());
	}
	
}
