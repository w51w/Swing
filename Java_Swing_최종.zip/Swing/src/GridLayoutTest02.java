import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.TextArea;

import javax.swing.JButton;
import javax.swing.JFrame;

public class GridLayoutTest02 extends JFrame{
	GridLayoutTest02(){
		super("그리드 레이아웃");
		setLayout(new GridLayout(4, 4));
		JButton 더하기 = new JButton("+");
		add(더하기);
		JButton 빼기 = new JButton("-");
		add(빼기);
		JButton 곱 = new JButton("*");
		add(곱);
		JButton 나누기 = new JButton("/");
		add(나누기);
		for(int i =0; i<10; i++) {
			JButton btn = new JButton(""+i);
			add(btn);
		}
		JButton 계산 = new JButton("=");
		add(계산);
		JButton 클리어 = new JButton("c");
		add(클리어);
		
	}
	void display() {
		setSize(300,300);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	public static void main(String[] args) {
		GridLayoutTest02 gt2 = new GridLayoutTest02();
		gt2.display();
	}

}
