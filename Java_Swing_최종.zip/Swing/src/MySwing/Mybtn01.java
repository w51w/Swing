package MySwing;

import java.awt.Container;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Mybtn01 extends JFrame{
	JButton btn; // 멤버변수
	
	Mybtn01(){
		super("자바");
		btn = new JButton("내가 만든 버튼");
		Container cp = getContentPane();
		//컨테이너는 만들지 않고 jframe 만들어 질때 자동생성되므로
		//가지고 와서 사용합니다.
		cp.add(btn);
	}
	public void display() {
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public static void main(String[] args) {
		Mybtn01 m1 = new Mybtn01();
		m1.display();
	}

}
