package MySwing;
import javax.swing.JFrame;


public class MySwing004 extends JFrame{
	MySwing004(){
		super("타이틀");
		setSize(400,400);
		setVisible(true);
	}

public static void main(String[] args) {
	MySwing004 m4 = new MySwing004();
}
}