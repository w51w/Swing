package MySwing;

import javax.swing.JFrame;

public class ex03 {

	public static void main(String[] args) {
		JFrame f = new JFrame("내가만든 프레임"); // 프레임 크기
		f.setSize(300, 300);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
