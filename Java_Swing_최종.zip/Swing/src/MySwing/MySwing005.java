package MySwing;

import javax.swing.JFrame;


class MySw01 extends JFrame{
	MySw01(){
		super("재미있는 자바");
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
}

public class MySwing005{
	public static void main(String[] args) {
		MySw01 m1 = new MySw01();
	}

}
