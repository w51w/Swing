package study0612;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class MyDraw01 extends JFrame{
	
	Point start=null, end=null;
	
	MyDraw01(){
		super("그림그리기");
		setSize(300, 300);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setContentPane(new MyPanel());
	}
	class MyPanel extends JPanel{
		MyPanel(){
			addMouseListener(new MyListener());
			addMouseMotionListener(new MyListener());
		}
		class MyListener extends MouseAdapter{
			public void mousePressed(MouseEvent e) {
				start = e.getPoint();
			}
			public void mouseDragged(MouseEvent e) {
				end = e.getPoint();
				repaint(); //paint(paintComponet)호출
			}
		}
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			if(start == null) {
				return;
			}
			g.setColor(Color.blue);
			int x,y,width,height;
			x = Math.min(start.x, end.x);
			y = Math.min(start.y, end.y);
			width = Math.abs(start.x - end.y);
			height = Math.abs(start.y - end.y);
			g.drawOval(x, y, width, height);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyDraw01 md1 = new MyDraw01();
	}

}
