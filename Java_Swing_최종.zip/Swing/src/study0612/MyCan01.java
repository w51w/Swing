package study0612;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;

public class MyCan01 extends JFrame{
	//메뉴선택시 작동하게 해줌
	public MyCan01(){
		FrameCanvas fc = new FrameCanvas();		
		fc.display();
	}
	public static void main(String[] args) {
		FrameCanvas fc = new FrameCanvas();		
		fc.display();
	}

}
class FrameCanvas extends JFrame {
	JButton clear;
	myCanvas canvas;
	public FrameCanvas() {
		clear = new JButton("clear");
		clear.addActionListener(new clearListener());
		add(clear);
		canvas = new myCanvas();
		canvas.setSize(300, 300);
		canvas.setBackground(Color.cyan);
		add(canvas);
		canvas.addMouseMotionListener(new MyListener());
	}
	class clearListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			Graphics g = canvas.getGraphics();
			g.clearRect(0, 0, 300, 500);
		}
		
	}
	class MyListener extends MouseAdapter{
		public void mouseDragged(MouseEvent e) {
			canvas.x = e.getX();
			canvas.y = e.getY();
			canvas.repaint();
		}
	}
	void display() {
		setLayout(new FlowLayout());
		setSize(300, 300);
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
}
class myCanvas extends Canvas{
	int x = 10 , y = 10;
	
	public void paint(Graphics g) {
		g.setColor(Color.yellow);
		g.fillOval(x, y, 5, 5);
	}
	public void update(Graphics g) {
		paint(g);
	}
}