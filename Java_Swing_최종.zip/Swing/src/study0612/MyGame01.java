package study0612;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class MyGame01 {
	//메뉴선택시 작동하게 해줌
	public MyGame01(){
		MyPuzzle01 mp = new MyPuzzle01();
		mp.display();
	}
	public static void main(String[] args) {
		MyPuzzle01 mp = new MyPuzzle01();
		mp.display();
	}

}
class MyPuzzle01 extends JFrame implements ActionListener{
	MyButton btn[];
	JPanel panel;
	int count = 0;
	MyPuzzle01() {
		int u[] = MyPuzzle01.makeRnum();
		panel = new JPanel(new GridLayout(3, 3,5,5));
		btn = new MyButton[10];
		for(int i =0; i<9; i++) {
			btn[i] = new MyButton("");
			btn[i].setText(""+ u[i]);
			btn[i].addActionListener(this);
			panel.add(btn[i]);
		}
		btn[8].setText("");
		btn[9] = new MyButton("Restart");
		btn[9].addActionListener(this);
	}
	
	void display() {
		setLayout(new BorderLayout());
		add(panel,BorderLayout.CENTER);
		add(btn[9],BorderLayout.SOUTH);
		setSize(400,400);
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		MyButton b = (MyButton)e.getSource();
		if(b.index == 9) {//Restart 누르면
			count = 0;
			setTitle("누른 횟수: " +count +"회");
			int u[] = MyPuzzle01.makeRnum();
			for(int i =0; i<9; i++) {
				btn[i].setText(""+ u[i]);
				btn[i].addActionListener(this);
			}
			btn[8].setText("");
		}
		if(b.getText().equals("") == true) return;
		if(b.index == 7) { // 인덱스 7번을 공백으로 만드려면
			count++;
			setTitle("누른 횟수: " +count +"회");
			if(btn[8].getText().equals("")) { 
				btn[8].setText(btn[7].getText());
				btn[7].setText("");
			}
			if(btn[4].getText().equals("")) { 
				btn[4].setText(btn[7].getText());
				btn[7].setText("");
			}
			if(btn[6].getText().equals("")) { 
				btn[6].setText(btn[7].getText());
				btn[7].setText("");
			}
		}
		if(b.index == 5) { //인덱스 5번을 공백으로 만드려면
			count++;
			setTitle("누른 횟수: " +count +"회");
			if(btn[8].getText().equals("")) { 
				btn[8].setText(btn[5].getText());
				btn[5].setText("");
			}
			if(btn[2].getText().equals("")) { 
				btn[2].setText(btn[5].getText());
				btn[5].setText("");
			}
			if(btn[4].getText().equals("")) { 
				btn[4].setText(btn[5].getText());
				btn[5].setText("");
			}
		}
		if(b.index == 1) { //인덱스 1번을 공백으로 만드려면
			count++;
			setTitle("누른 횟수: " +count +"회");
			if(btn[0].getText().equals("")) { 
				btn[0].setText(btn[1].getText());
				btn[1].setText("");
			}
			if(btn[2].getText().equals("")) { 
				btn[2].setText(btn[1].getText());
				btn[1].setText("");
			}
			if(btn[4].getText().equals("")) { 
				btn[4].setText(btn[1].getText());
				btn[1].setText("");
			}
		}
		if(b.index == 3) { //인덱스 3번을 공백으로 만드려면
			count++;
			setTitle("누른 횟수: " +count +"회");
			if(btn[0].getText().equals("")) { 
				btn[0].setText(btn[3].getText());
				btn[3].setText("");
			}
			if(btn[4].getText().equals("")) { 
				btn[4].setText(btn[3].getText());
				btn[3].setText("");
			}
			if(btn[6].getText().equals("")) { 
				btn[6].setText(btn[3].getText());
				btn[3].setText("");
			}
		}
		if(b.index == 8) {//인덱스 8번을 공백으로 만드려면
			count++;
			setTitle("누른 횟수: " +count +"회");
			if(btn[5].getText().equals("")) { 
				btn[5].setText(btn[8].getText());
				btn[8].setText("");
			}
			if(btn[7].getText().equals("")) { 
				btn[7].setText(btn[8].getText());
				btn[8].setText("");
			}
		}
		if(b.index == 6) {//인덱스 6번을 공백으로 만드려면
			count++;
			setTitle("누른 횟수: " +count +"회");
			if(btn[3].getText().equals("")) { 
				btn[3].setText(btn[6].getText());
				btn[6].setText("");
			}
			if(btn[7].getText().equals("")) { 
				btn[7].setText(btn[6].getText());
				btn[6].setText("");
			}
		}
		if(b.index == 0) {//인덱스 0번을 공백으로 만드려면
			count++;
			setTitle("누른 횟수: " +count +"회");
			if(btn[1].getText().equals("")) { 
				btn[1].setText(btn[0].getText());
				btn[0].setText("");
			}
			if(btn[3].getText().equals("")) { 
				btn[3].setText(btn[0].getText());
				btn[0].setText("");
			}
		}
		if(b.index == 2) {//인덱스 2번을 공백으로 만드려면
			count++;
			setTitle("누른 횟수: " +count +"회");
			if(btn[1].getText().equals("")) { 
				btn[1].setText(btn[2].getText());
				btn[2].setText("");
			}
			if(btn[5].getText().equals("")) { 
				btn[5].setText(btn[2].getText());
				btn[2].setText("");
			}
		}
		if(b.index == 4) {//인덱스 4번을 공백으로 만드려면
			count++;
			setTitle("누른 횟수: " +count +"회");
			if(btn[1].getText().equals("")) { 
				btn[1].setText(btn[4].getText());
				btn[4].setText("");
			}
			if(btn[3].getText().equals("")) { 
				btn[3].setText(btn[4].getText());
				btn[4].setText("");
			}
			if(btn[5].getText().equals("")) { 
				btn[5].setText(btn[4].getText());
				btn[4].setText("");
			}
			if(btn[7].getText().equals("")) { 
				btn[7].setText(btn[4].getText());
				btn[4].setText("");
			}
		}
	}
	static int[] makeRnum() {
		Random r = new Random();
		int result[] = new int[9];
		int x=0;
		for(int i =0; i<8; i++) {
			result[i] = r.nextInt(8) + 1;
			//중복체크 반복문
			for(int k = 0; k<i; k++) { 
				if(result[i] == result[k]) { //중복이라면
					x = r.nextInt(8)+1;
					result[i] = x;	
					i = i-1;
					break;
				}
			}
		}
		return result;
	}
}

class MyButton extends JButton{
	static int count =0;
	int index;
	public MyButton(String s) {
		super(s);
		index = count++;
	}
}