package 명품자바책;

import java.awt.*;
import javax.swing.*;

public class ContentPaneEx extends JFrame{
	ContentPaneEx(){
		setTitle("ContendtPane과 JFrame 예제");//프레임 타이틀
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//프레임 윈도우 닫으면 프로그램 종료
		
		Container contentPane = getContentPane();//컨텐트팬을 알아낸다.
		contentPane.setBackground(Color.ORANGE);//배경 오랜지색
		contentPane.setLayout(new FlowLayout());//컨텐트팬에 FlowLayout 배치관리자 달기
		
		//버튼//
		contentPane.add(new JButton("OK"));
		contentPane.add(new JButton("Cancle"));
		contentPane.add(new JButton("Ignore"));
		
		setSize(300,150);//프레임 크기 300x150 설정
		setVisible(true);//화면에 프레임 보이기
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//종료시 그냥 안보이게 되지만 이 코드가 있다면
														//프레임 윈도우 종료시 프로그램 종료시 함께 종료되도록한다.
	}
	public static void main(String[] args) {
		new ContentPaneEx();
	}

}
