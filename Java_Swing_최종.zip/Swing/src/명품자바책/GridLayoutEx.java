package 명품자바책;

import java.awt.*;

import javax.swing.*;

public class GridLayoutEx extends JFrame{
	public GridLayoutEx(){
		super("GridLayout 예제");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//프레임 윈도우 종료시 프로그램 종료시 함께 종료되도록한다.
		Container contentPane = getContentPane(); //컨텐트팬 알아내기
		
		contentPane.setLayout(new GridLayout(1, 10)); //(rows, cols, hgap, vgap), 디폴트(1,1,0,0)
		
		for(int i =0; i<10; i++) {//10번 반복
			String text = Integer.toString(i); //i -> 문자열 변환
			JButton button = new JButton(text);//버튼 컴포넌트 생성
			contentPane.add(button);//컨텐트펜에 부착
		}
		
		setSize(500,200);
		setVisible(true);
	}
	public static void main(String[] args) {
		new GridLayoutEx();
	}

}
