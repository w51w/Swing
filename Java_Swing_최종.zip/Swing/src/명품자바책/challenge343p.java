package 명품자바책;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class challenge343p extends JFrame{
	challenge343p(){
		setTitle("간단한 스윙 프로그램 만들기");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container c = getContentPane();
		//c.setLayout(new BorderLayout()); 프레임의 디폴트 레이아웃은 Border이다. 즉 있으나 없으나 무시되는 코드이다
		c.add(new NorthPanel(),BorderLayout.NORTH);
		c.add(new CenterPanel(), BorderLayout.CENTER);

		setSize(500,500);
		setVisible(true);
	}
	
	public static void main(String[] args) {
		challenge343p ch = new challenge343p();
	}
}
class NorthPanel extends JPanel{
	public NorthPanel() {
		// TODO Auto-generated constructor stub
		this.setBackground(Color.black);
		this.add(new JButton("Open"));
		this.add(new JButton("Read"));
		this.add(new JButton("Close"));
	}
}
class CenterPanel extends JPanel{
	public CenterPanel() {
		// TODO Auto-generated constructor stub
		this.setLayout(null);
		JLabel lb = new JLabel("Java");
		lb.setSize(100, 20);
		lb.setLocation(120, 50);
		this.add(lb);
		
	}
}


