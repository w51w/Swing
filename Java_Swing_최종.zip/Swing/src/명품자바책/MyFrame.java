package 명품자바책;

import javax.swing.JFrame;

public class MyFrame extends JFrame{
	MyFrame(){
		setTitle("300x300 스윙 프레임 만들기");//프레임 사이틀 설정
		setSize(300,300);//프레임 크기 설정
		setVisible(true);//프레임이 화면에 나타나도록 지시. false경우 프레임이 숨겨짐
	}
	public static void main(String[] args) {
		MyFrame frame = new MyFrame(); //스윙 프레임 생성
	} 

}
