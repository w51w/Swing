package 명품자바책;

import java.awt.*;

import javax.swing.*;

public class BorderLayoutEx extends JFrame{
	BorderLayoutEx(){
		setTitle("BorderLayout 예제");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//프레임 윈도우 종료시 프로그램 종료시 함께 종료되도록한다.
		Container contentPane = getContentPane(); //컨텐트팬 알아내기
		
		contentPane.setLayout(new BorderLayout(30, 20));//수평간격,수직간격(px)
		
		contentPane.add(new Button("Calculate"), BorderLayout.CENTER);
		contentPane.add(new Button("add"), BorderLayout.NORTH);
		contentPane.add(new Button("sub"), BorderLayout.SOUTH);
		contentPane.add(new Button("mul"), BorderLayout.EAST);
		contentPane.add(new Button("div"), BorderLayout.WEST);
		
		setSize(300,200);
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new BorderLayoutEx();
	}

}
