package 명품자바책;

import java.awt.Container;

import javax.swing.*;
import java.awt.*;

public class NullContainerEx extends JFrame{
	NullContainerEx(){
		setTitle("배치관리자 없이 절대 위치에 배치하는 예제");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//프레임 윈도우 종료시 프로그램 종료시 함께 종료되도록한다.
		Container contentPane = getContentPane();//컨텐트팬 알아내기
		
		contentPane.setLayout(null); // 컨텐트팬의 배치관리자 제거
		
		JLabel la = new JLabel("Hello Press Buttons!");//JLabel 컴포넌트 생성
		la.setLocation(130, 50);//la 위치지정
		la.setSize(200, 20);//la 크기지정
		contentPane.add(la);//la를 부착
		
		for(int i =0; i<=9; i++) {
			JButton b = new JButton(Integer.toString(i));//버튼생성
			b.setLocation(i*15, i*15);//b 위치
			b.setSize(50, 20);//b 사이즈
			contentPane.add(b);//b 부착
		}
		
		setSize(300,200);
		setVisible(true);
	}
	public static void main(String[] args) {
		new NullContainerEx();
	}

}
