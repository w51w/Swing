package socket;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client01 {
	Socket sock;
	PrintWriter out;
	BufferedReader in;
	BufferedReader std_in;
	
	public static void main(String[] args) throws IOException {
		Client01 c = new Client01();
		c.sendMsg();
	}
	
	public Client01() {
		try {
			sock = new Socket("127.0.0.1", 4444); 		//소캣 생성
			out = new PrintWriter(sock.getOutputStream(), true);
			// 출력용 스트림 생성
			in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			// 입력용 스트림 생성
		}
		catch (UnknownHostException e) {
			System.err.println(e);
			System.exit(1);
		}
		catch (IOException e) {
			System.err.println(e);
			System.exit(1);
		}
		System.out.println("소켓 생성 완료");
		std_in = new BufferedReader(new InputStreamReader(System.in));
	}
	public void sendMsg() throws IOException{
		String server_str;
		String client_str;
		
		System.out.println("이름을 입력해주세요");
		client_str = std_in.readLine(); //입력
		System.out.println("당신의 이름" + client_str + "를(을) 서버에 보냅니다.");
		out.println(client_str); 		//서버에 보냄
		server_str = in.readLine(); 	//서버에서 받음
		System.out.println("서버에서 보낸 응답입니다.");
		System.out.println(server_str);

		out.close(); //스트림 닫기
		std_in.close();
		sock.close(); //소켓 닫기
		
	}
}

