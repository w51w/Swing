package socket;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server01 {
	ServerSocket serverSocket; //1. 소켓 생성
	Socket sock;
	PrintWriter out; //2. 입출력 스트림
	BufferedReader in;
	public static void main(String[] args) throws IOException{
		while(true) {
			Server01 s = new Server01();
			s.receiveMsg();
		}
		
	}
	
	public Server01() {
		try {
			//3. 클라이언트를 기다리는 listen
			serverSocket = new ServerSocket(4444);
			//ServerSocket 생성
		}
		catch(IOException e) {
			System.err.println(e);
			System.exit(1);
		}
		System.out.println("서버 소켓 생성완료(연결 대기중)");
		try {
			sock = serverSocket.accept();
			//4. 클라이언트를 기다리면서 연결시까지 대기
			out = new PrintWriter(sock.getOutputStream(), true);
	//		out = new PrintWriter(sock.getOutputStream());
			//출력용 스트림 생성
			in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			//입력용 스트림 생성
		}
		catch(IOException e) {
			System.err.println(e);
			System.exit(1);
		} 
		System.out.println("소켓 생성 완료(연결됨).");
	}
	
	
	public void receiveMsg() throws IOException{
		String inputLine;
		System.out.println("메시지를 기다리고 있습니다");
		inputLine = in.readLine();
		System.out.println("메시지가 도착했습니다");
		out.println("안녕하세요, " + inputLine + "님");
		System.out.println("응답을 보냈습니다.");
		
		//출력 스트림을 통해 데이터 보내기
		out.close();
		//6. 스트림 닫기
		in.close();
		sock.close();
		//7. 소켓 닫기
		serverSocket.close();
		//서버 소켓 닫기
	}

}
