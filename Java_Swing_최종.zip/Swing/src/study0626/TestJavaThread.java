package study0626;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.GregorianCalendar;

public class TestJavaThread extends Thread{
	Socket sock;
	PrintWriter out; //출력용
	
	public TestJavaThread(Socket sock) {
		super();
		this.sock = sock;
		System.out.println("스레드 주소를 지역변수에 저장"+sock);
	}
	
	public void run() {
		try {
			System.out.println("sock.getOutputStream()");
			out = new PrintWriter(sock.getOutputStream(), true);
			GregorianCalendar gc = new GregorianCalendar();
			String d = gc.get(gc.HOUR_OF_DAY)+":"+gc.get(gc.MINUTE);
			//String d= (gc.get(gc.MONDAY)+1)+":"+gc.get(gc.DATE);
			System.out.println("클라이언트에 전송");
			out.println(d);
			System.out.println(sock.getInetAddress().getHostAddress() + "에게 날짜를 전송했습니다.");
			
		}
		catch(Exception e) {
			System.err.println(e);
		}
		finally {
			try {
				sock.close();
			}
			catch(IOException e) {
				
			}
		}
	}
}
