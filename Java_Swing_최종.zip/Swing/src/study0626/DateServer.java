package study0626;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.GregorianCalendar;

public class DateServer {
	ServerSocket ss;
	Socket sock;
	PrintWriter out;
	BufferedReader in;
	public DateServer() {
		try {
			ss = new ServerSocket(4444);
		}
		catch(IOException e) {
			System.exit(1);
		}
		
		while(true) {
			try {
				System.out.println("클라이언트 요청 대기");
				sock = ss.accept(); //대기
				System.out.println("스레드 생성자 생성");
				TestJavaThread task = new TestJavaThread(sock);
				System.out.println("스레드 run()");
				task.start();
				
				//out = new PrintWriter(sock.getOutputStream(), true);
				//out.println("" + new Date());
			}
			catch(IOException e) {
				System.err.println(e);
				System.exit(1);
			}
		
			System.out.println("소켓 생성완료(연결 대기중).");//accept
			}
		}
	
	public void receiveMsg() throws IOException{
		out = new PrintWriter(sock.getOutputStream(), true);
		in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
	}
//---------------메인
	public static void main(String[] args) throws IOException{
		System.out.println("server생성자 생성 ");
		DateServer ds = new DateServer();
		System.out.println("ds.receiveMsg 메소드 실행");
		ds.receiveMsg();
		
	}	
}
