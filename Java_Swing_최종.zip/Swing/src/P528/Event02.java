package P528;

import java.awt.Container;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class Event02 extends JFrame{
	Container c;
	JLabel lb;
	Event02(){
		c = getContentPane();
		lb = new JLabel("hello");
		lb.setSize(70, 50);
		lb.setLocation(100, 100);
		c.add(lb);
		c.addMouseListener(new MyMouse());
		}
	
	class MyMouse extends MouseAdapter{
		public void mouseClicked(MouseEvent e) {
			lb.setLocation(e.getX(), e.getY());
		}
	}
	/*class MyMouse implements MouseListener{

		public void mouseClicked(MouseEvent e) {
			
		}
		public void mouseEntered(MouseEvent e) {//마우스 들어올 때
		}
		public void mouseExited(MouseEvent e) {//마우스 빠져나갈 때
			
		}
		public void mousePressed(MouseEvent e) {	
			
		}
		public void mouseReleased(MouseEvent e) {
		lb.setLocation(e.getX(), e.getY());
		}
		
	}
*/
	void display() {
		setLayout(null); //레이아웃 없이
		setVisible(true);
		setSize(500,500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public static void main(String[] args) {
		Event02 e = new Event02();
		e.display();
	}

}
