package P528;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
//import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class Event03 extends JFrame{
	Container c;
	JLabel lb;
	int x = 100;
	int y = 100;
	Event03(){
		
		c = getContentPane();
		lb = new JLabel("hello");
		lb.setSize(70, 50);
		lb.setLocation(x, y);
		c.add(lb);
		c.addMouseListener(new MyMouse());
		c.addKeyListener(new MyKey());
		c.setFocusable(true);
		}
	class MyKey extends KeyAdapter{
		public void keyPressed(KeyEvent e) {
			
			if (e.getKeyChar() == 'q') {
				System.exit(0);
			}
			if(e.getKeyCode()==KeyEvent.VK_ENTER) {
				int r = (int)(Math.random()*256);
				int g = (int)(Math.random()*256);
				int b = (int)(Math.random()*256);
				getContentPane().setBackground(new Color(r,g,b));
			}
			if(e.getKeyCode() == KeyEvent.VK_LEFT) {
				x = x-20;
				lb.setLocation(x, y);
			}
			if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
				x = x+20;
				lb.setLocation(x, y);
			}
			if(e.getKeyCode() == KeyEvent.VK_UP) {
				y = y-20;
				lb.setLocation(x, y);
			}
			if(e.getKeyCode() == KeyEvent.VK_DOWN) {
				y = y+20;
				lb.setLocation(x, y);
			}
		}
	}
	class MyMouse extends MouseAdapter{
		public void mouseClicked(MouseEvent e) {
			x = e.getX(); y= e.getY();
			lb.setLocation(e.getX(), e.getY());
		}
	}
	/*class MyMouse implements MouseListener{

		public void mouseClicked(MouseEvent e) {
			
		}
		public void mouseEntered(MouseEvent e) {//마우스 들어올 때
		}
		public void mouseExited(MouseEvent e) {//마우스 빠져나갈 때
			
		}
		public void mousePressed(MouseEvent e) {	
			
		}
		public void mouseReleased(MouseEvent e) {
		lb.setLocation(e.getX(), e.getY());
		}
		
	}
*/
	void display() {
		setLayout(null); //레이아웃 없이
		setVisible(true);
		setSize(500,500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public static void main(String[] args) {
		Event03 e = new Event03();
		e.display();
	}

}
