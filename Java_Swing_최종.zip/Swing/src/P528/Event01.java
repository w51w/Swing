package P528;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class Event01 extends JFrame implements ActionListener{
	JButton btn;
	JTextField tf;
	
	Event01(){
		super("이벤트 리스너");
		btn = new JButton("버튼");
		btn.addActionListener(this);
		add(btn);
		tf = new JTextField(20);
		tf.addActionListener(this);
		add(tf);
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == btn)
			tf.setText("");
		if(e.getSource() == tf) {
			btn.setText(tf.getText());
		}
	}
	void display() {
		setLayout(new FlowLayout());
		setVisible(true);
		setSize(500,500);
	}

	public static void main(String[] args) {
		Event01 e = new Event01();
		e.display();
	}

}
