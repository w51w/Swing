package net01;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

class ChatThread extends Thread{
	NetChatServer xServer;
	Socket sock;
	int state;
	String userName;
	PrintWriter out;
	BufferedReader input;
	
	public ChatThread (NetChatServer server, Socket socket) {
		xServer = server;
		System.out.println("소켓을 스레드 지역변수에 저장");
		sock = socket;
		state = 0;
		out = null;
		input = null;
	}
	//메시지 전달
	public void sendMessage(String msg) throws IOException{
		if(out != null) {
			out.println(msg);
		}
	}
	public void run() {
		try {
			out = new PrintWriter(sock.getOutputStream(), true);
			input = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			String il; // 클라이언트로 부터 입력 받은 값을 저장하는 변수
			state = 1; // 초기상태 (채팅전 전 상태)
			out.println("ready");
			if("connected".equals(input.readLine())) {
				state =2 ; //접속한 상태
				out.println("username");
				userName = input.readLine();
				state = 3; // 대화가능 상태(방송가능상태)
				sendMessage(userName);
				xServer.broadcast("#" + userName + "님이 입장");
			}
			else {
				sendMessage("지원하지 않는 테미널");
				userName="몰라요";
				state = 3; // 대화가능 상태(방송가능상태)
			}
			while((il = input.readLine()) != null) {
				if(il.equals("/h")) {
					sendMessage("#도움말\n"
							+"/h : 도움말\n"
							+"/u : 전체사용자\n"
							+"/c : 사용자이름 : 사용자이름바꾸기\n");
				}
				else if( il.equals("/u")) {
					xServer.sendUserList(ChatThread.this);
				}
				//regionMatches (0) 객체시작위치 0에서 2보다 작은 값비교해서
				//문자 두개 비교해서 "/c"와 같다면
				else if(il.regionMatches(0, "/c", 0, 2)) {
					String new_name = il.substring(2).trim();
					xServer.broadcast("#사용자" + userName + "님의 이름이["+ new_name +"]으로 바꿨습니다.");
					userName = new_name;
				}
				else {
					xServer.broadcast("["+userName+"]" + il);
				}
			}
			
		}
		catch(IOException e) {
			xServer.removeClient(this);
			System.out.println("클라이언트\n" + sock + "\n접속이 끊김");
			System.out.println("\n접속이 끊김");
		}
	}
}

public class NetChatServer{
	Vector vClient;
	public NetChatServer() {
		//사용자는 벡터형 클래스 = 가변 길이 배열
		vClient = new Vector();
	}
	public void addClient(ChatThread thd) {
		vClient.addElement(thd);
	}
	public void removeClient(ChatThread thd) {
		vClient.removeElement(thd);
	}
	public void sendUserList(ChatThread client) throws IOException{
		if(client.state<3) return;
		client.sendMessage("#사용자 리스트");
		for(int i =0; i<vClient.size(); i++) {
			//elementAt(i)= 각각의 사용자를 구분한다
			ChatThread thd = ((ChatThread)vClient.elementAt(i));
			client.sendMessage(thd.userName);
		}
	}
	//모든 사용자에게 메시지를 보낸다
	public void broadcast(String msg) throws IOException{
		for(int i =0; i<vClient.size(); i++) {
			ChatThread thd = ((ChatThread)vClient.elementAt(i));
			if(thd.state>=3) thd.sendMessage(msg);
		}
	}
	
	
	
	public static void main(String[] args) {
		NetChatServer server;
		ServerSocket serverSocket = null;
		int port = 4444;
		boolean listening = true;
		System.out.println("서버 벡터(클라이언트 목록) 생성");
		server = new NetChatServer();
		try {
			System.out.println("서버 소켓 생성");
			serverSocket = new ServerSocket(port);
		}
		catch(IOException e) {
			System.out.println("연결 실패");
			System.exit(-1);
		}
		System.out.println("서버\n" + serverSocket + "\n에서 연결을 기다립니다.");
//		System.out.println("클라이언트의 연결을 기다립니다.");
		try {
			while(listening) {
				ChatThread thread;
				System.out.println("메인,while,스레드 객체 생성");
				thread = new ChatThread(server, serverSocket.accept());
				System.out.println("스레드 run()");
				thread.start();
				System.out.println("클라이언트 목록에 추가");
				server.addClient(thread);
			}
		}
		catch(IOException e) {
			System.out.println("서버를 종료");
		}
		catch(Exception e) {
			System.err.println(e);
		}
		finally {
			try {
				serverSocket.close();
			}
			catch(IOException e) {}
		}
	}
}
