package net01;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class NetChatClient extends JFrame implements Runnable
{
	int state = 0;
	Socket chatSocket = null;
	PrintWriter out = null;
	BufferedReader input = null;
    JTextArea  ta;	//공유창
    JTextField  tf; //입력창
      
	public NetChatClient(String title)
	{
		super(title);
		setLayout(new BorderLayout());
		ta=new JTextArea(10,30);
		tf=new JTextField(30);
		ta.setFont(new Font("",Font.PLAIN,20));
		ta.setEditable(false);
		tf.setFont(new Font("",Font.BOLD,20));
		add(new JScrollPane(ta),BorderLayout.CENTER);
		add(tf,BorderLayout.SOUTH);
		tf.addActionListener(new MyListener()); //텍스트필드에서 엔터
	}
	public void display()
	{
		setVisible(true);
		setSize(500,800);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
	public void addMessage(String msg)
	{
		ta.append(msg+"\n");//텍스트 에어리어에 누적
	}
	public void connect(String host,int port)// 호스트.포트
	{
		try
		{
			chatSocket = new Socket(host,port);
			out = new PrintWriter(chatSocket.getOutputStream(),true);
			input = new BufferedReader(new InputStreamReader(chatSocket.getInputStream()));
			state=1;//초기상태
			if("ready".equals(input.readLine()))
			{
				System.out.println("state1 초기상태 서버로 connected문자열 보내고 state2로 바꿈");
				out.println("connected");
				state=2; //접속한 상태
			}
		}
			catch(UnknownHostException e)
			{
				System.err.println("호스트가 이상합니다.");
				System.exit(1);
			}
			catch (IOException ie)
			{
				System.err.println("입출력이 이상!");
      			System.exit(1);
			}
			Thread thd;
			thd=new Thread(this);
			thd.start();
		}
		public void disconnect()
		{
			try
			{
				out.close();
				input.close();
				chatSocket.close();
				state=0;
			}
			catch(IOException e){}
		}
public void run()
{
	try
	{
		while(true)
		{
			if (state >=2) //접속한 상태
			{
				addMessage(input.readLine());
//				ta.append(input.readLine());
			}
		}//end of while
	} // end of try
	catch(IOException e)
		{		
			disconnect();
		}
}  // end of run 
		
	public static void main(String arg[])
	{
		NetChatClient mf = new NetChatClient("chat client");
		mf.display();

		if(arg.length<2)
		{
			System.out.println("사용법\n java NetChatClient 서버이름 포트번호");
//			return;
		}
		//	mf.connect(arg[0],Integer.valueOf(arg[1]).intValue());
			mf.connect("127.0.0.1",4444);//172.16.52.222
	}
	class MyListener implements ActionListener
	{
		public void actionPerformed(ActionEvent ae)
		{
			if(state<2) return;
			String input = tf.getText();
			tf.setText("");
			try
			{
				out.println(input);
			}
			catch(Exception e){}
		}
	}  //end of MyListener class
} // end of NetChatClient class

