import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class LayoutTest01 extends JFrame{
	JButton btn1, btn2, btn3, btn4, btn5;
	LayoutTest01(){
		btn1 = new JButton("버튼1");
		btn2 = new JButton("버튼2");
		btn3 = new JButton("버튼3");
		btn4 = new JButton("버튼4");
		btn5 = new JButton("버튼5");
		setLayout(new BorderLayout(10, 10));
		add(btn1,BorderLayout.CENTER);
		add(btn2,BorderLayout.EAST);
		add(btn3,BorderLayout.WEST);
		add(btn4,BorderLayout.SOUTH);
		add(btn5,BorderLayout.NORTH);
	}
	void display() {
		setSize(300,300);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	public static void main(String[] args) {
		LayoutTest01 lt1 = new LayoutTest01();
		lt1.display();

	}

}
