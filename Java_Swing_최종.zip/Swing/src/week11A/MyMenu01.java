package week11A;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.ServerSocket;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;


import net01.NetChatClient;
import net01.NetChatServer;
import study0612.MyCan01;
import study0612.MyGame01;

public class MyMenu01 extends JFrame implements ActionListener{
	Container c;
	JLabel imgLabel;
	JMenuBar mb;
	JMenu screenMenu,project;
	JMenuItem load,hide,reshow,exit;
	JMenuItem calculator,painter,puzzle,chatting,game;
	MyMenu01(){
		c=getContentPane();
		
		imgLabel = new JLabel("aaa");
		c.setLayout(new FlowLayout());
		c.add(imgLabel);
		
		mb = new JMenuBar();
		screenMenu = new JMenu("Screen");
		project = new JMenu("Project");
		
		load = new JMenuItem("Load");
		load.addActionListener(this);
		hide = new JMenuItem("hide");
		hide.addActionListener(this);
		reshow = new JMenuItem("reshow");
		reshow.addActionListener(this);
			
		exit = new JMenuItem("exit");
		exit.addActionListener(this);
		//프로젝트 메뉴 아이템
		calculator = new JMenuItem("calculator");
		calculator.addActionListener(this);
		painter = new JMenuItem("painter");
		painter.addActionListener(this);
		puzzle = new JMenuItem("puzzle");
		puzzle.addActionListener(this);
		chatting = new JMenuItem("chatting");
		chatting.addActionListener(this);
		game = new JMenuItem("game");
		game.addActionListener(this);		
		///
		screenMenu.add(load);
		screenMenu.add(hide);
		screenMenu.add(reshow);
		screenMenu.addSeparator(); //분리선
		screenMenu.add(exit);
		//
		project.add(calculator);
		project.add(painter);
		project.add(puzzle);
		project.add(chatting);
		project.add(game);
		//메뉴바에 메뉴 add
		mb.add(screenMenu);
		mb.add(project);
		//메뉴바를 프레임에 add
		setJMenuBar(mb);
	}
	void display() {
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyMenu01 mm = new MyMenu01();
		mm.display();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == exit) {
			System.exit(0);
		}
		else if(e.getSource() == load) {
			imgLabel.setIcon(new ImageIcon("Swing/MySwing/img/img01.png"));
		}
		else if(e.getSource() == hide) {
			imgLabel.setVisible(false);
		}
		else if(e.getSource() == reshow) {
			imgLabel.setVisible(true);
		}
		else if(e.getSource() == painter) {
			new MyCan01();
		}
		else if(e.getSource() == calculator) {
			new MyCal();
		}
		else if(e.getSource() == puzzle) {
			new MyGame01();
		}
		else if(e.getSource() == chatting) {
			NetChatClient mf = new NetChatClient("chat client");

			//	mf.connect(arg[0],Integer.valueOf(arg[1]).intValue());
				mf.connect("127.0.0.1",4444);//172.16.52.222
				mf.display();
			
		}
		else if(e.getSource() == game) {
			Level l = new Level();
			l.display();
		}
	}
}
