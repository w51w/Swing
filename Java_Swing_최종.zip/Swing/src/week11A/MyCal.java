package week11A;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class MyCal extends JFrame implements ActionListener{
	Container c;
	JTextField tf;
	JPanel panel, digitPanel, opPanel;
	JButton plus,minus,multi,divide,answer,clear;
	JButton digit[];
	String prev, op;
	String tf_num ="";
	double result = 0;
	MyCal(){
		super("Calculator");
		c= getContentPane();
		///텍스트필드
		panel = new JPanel();
		tf = new JTextField(20);
		tf.setHorizontalAlignment(JTextField.RIGHT);
		panel.add(tf);	
		//연산자
		opPanel = new JPanel();
		opPanel.setLayout(new GridLayout(4, 1,5,5));
		plus = new JButton("+");
		plus.setBackground(new Color(255,255,150));
		plus.addActionListener(this);
		opPanel.add(plus);
		minus = new JButton("-");
		minus.setBackground(new Color(255,255,150));
		minus.addActionListener(this);
		opPanel.add(minus);
		multi = new JButton("*");
		multi.setBackground(new Color(255,255,150));
		multi.addActionListener(this);
		opPanel.add(multi);
		divide = new JButton("/");
		divide.setBackground(new Color(255,255,150));
		divide.addActionListener(this);
		opPanel.add(divide);
		///숫자
		digitPanel = new JPanel();
		digitPanel.setLayout(new GridLayout(4, 3,5,5));
		digit = new JButton[10];
		for(int i =1; i<10; i++) {
			digit[i] = new JButton(""+i); 
			digit[i].setBackground(new Color(255,255,255));
			digit[i].addActionListener(this);
			digitPanel.add(digit[i]);
		}
		//clear
		clear = new JButton("c");
		clear.setBackground(new Color(255,150,255));
		clear.addActionListener(this);
		digitPanel.add(clear);
		// zero
		digit[0] = new JButton(""+0); 
		digit[0].setBackground(new Color(255,255,255));
		digit[0].addActionListener(this);
		digitPanel.add(digit[0]);
		//
		//answer
		answer = new JButton("=");
		answer.setBackground(new Color(255,150,255));
		answer.addActionListener(this);
		digitPanel.add(answer);
		//
		
		c.add(panel, BorderLayout.NORTH); // tf
		c.add(opPanel, BorderLayout.EAST);//연산자
		c.add(digitPanel, BorderLayout.CENTER);
		
		display();//메뉴선택시 작동하게 해줌
	}
	void display() {
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyCal cal = new MyCal();
		cal.display();
	}
	@Override
	public void actionPerformed(ActionEvent e) {		
		String input = e.getActionCommand();
		
		if(input == clear.getText()) {
			prev = "";
			op = "";
			tf_num = "";
			tf.setText(tf_num);
			return;
		}
		if((input == plus.getText()) ||
				(input == minus.getText()) ||
				(input == multi.getText()) ||
				(input == divide.getText())) {
			prev = tf_num;
			tf_num ="";
			op = input;
			tf.setText(tf_num);
			return;
		}
		if(input == answer.getText()) {
			calc c = new calc();
			tf_num = c.getResult(prev, op, tf_num);
			prev = "";
			op = "";
			tf.setText(tf_num);
			return;
		}
		
		tf_num += input;
		tf.setText(tf_num);
	}
}
class calc{
	double oped1, op, oped2;
	double result = 0;
	String returnString;
	public String getResult(String prev, String op, String tf_num){
		oped1 = Double.parseDouble(prev);
		oped2 = Double.parseDouble(tf_num);
		if(op.equals("+")) {
			result =  oped1 + oped2;
		}
		else if(op.equals("-")) {
			result = oped1 - oped2;
		}
		else if(op.equals("*")) {
			result = oped1 * oped2;
		}
		else if(op.equals("/")) {
			result = oped1 / oped2;
		}
		returnString = Double.toString(result);
		return returnString;
	}
	
}