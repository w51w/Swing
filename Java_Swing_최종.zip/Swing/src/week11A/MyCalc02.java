package week11A;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

class MyCalc02 extends JFrame{

	public static void main(String[] args) {
		MyKey mk = new MyKey();
		mk.display();

	}
}

class MyKey extends JFrame
{
	JPanel panel;
	JButton btn[];
	JButton opBtn[];
	JTextField tf;
	String operator;
	String op1,op2;
	float i,j,k;
	MyKey()
	{
		super("Calculator");
		operator ="";
		op1="";op2="";
		panel = new JPanel(new GridLayout(4,4));
		ImageIcon ii = new ImageIcon("1.png");
		
		btn = new JButton[12];//0~9 C,=
		opBtn=new JButton[4];
		for(int i=0;i<10;i++)
		{
			btn[i] = new JButton(""+i,ii);
			btn[i].addActionListener(new BtnListener());
			panel.add(btn[i]);
		}
		opBtn[0] = new JButton("+");opBtn[1] = new JButton("-");
		opBtn[2] = new JButton("*");opBtn[3] = new JButton("/");
		for(int i=0;i<4;i++)
		{
			opBtn[i].addActionListener(new BtnListener());
			panel.add(opBtn[i]);
		}
		btn[10] = new JButton("=");
		btn[10].addActionListener(new BtnListener());
		panel.add(btn[10]);
		///////////////////////////
		btn[11] = new JButton("C");
		btn[11].addActionListener(new BtnListener());
		panel.add(btn[11]);
		tf = new JTextField(26);
		add(tf);add(panel);
		
	}
	class BtnListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {

			// TODO Auto-generated method stub
			for(int i=0;i<10;i++)
			{
				if(e.getSource()==btn[i])
				{
					op1 += e.getActionCommand();//��ư�� ���̺�
					tf.setText(op1);
					tf.setHorizontalAlignment(4);
				}
			}
			//operator
			if((e.getActionCommand()=="+")|(e.getActionCommand()=="-")|
			(e.getActionCommand()=="*")|(e.getActionCommand()=="/"))
			{
				operator = e.getActionCommand();
				op2=op1;
				op1="";
				i=Float.parseFloat(op2);
			}
			/////////// ===== 
			if(e.getActionCommand()=="=")
			{
				j=Float.parseFloat(op1);
				op1 = Float.toString(oper(operator,i,j));
				tf.setText(op1);
			}
			if(e.getSource()==btn[11])
			{
				op1="";
				tf.setText(op1);
			}
	
		}
		public float oper(String operator,float i,float j)
		{
			if(operator.equals("+"))
				k=i+j;
			if(operator.equals("-"))
				k=i-j;
			if(operator.equals("*"))
				k=i*j;
			if(operator.equals("/"))
				k=i/j;
			return k;
		}
		
	}
	void display() {
	
		setLayout(new FlowLayout());
		setVisible(true);
		setSize(400, 350);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);	// �� ��ü�� ������.
	}
}
