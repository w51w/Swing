package week11A;

import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JScrollPane;

public class JList01 extends JFrame{
	Container c;
	JList<String> fruits;
	ImageIcon images;
	JList01(){
		c=getContentPane();
		c.setLayout(new FlowLayout());
		String items[] = {"사과","배","복숭아","딸기","수박","사과","배","복숭아","딸기","수박"};
		fruits = new JList<String> (items);
		//c.add(fruits);
		c.add(new JScrollPane(fruits));
		/////리스트에 그림 추가
		ImageIcon [] images = {new ImageIcon("img/fru01.PNG"),
				new ImageIcon("img/fru02.PNG"),
				new ImageIcon("img/fru03.PNG"),
				new ImageIcon("img/fru04.PNG"),
				new ImageIcon("img/fru05.PNG")};
		JList<ImageIcon> imageList = new JList();
		imageList.setListData(images);
		c.add(imageList);
	}
	void display() {
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JList01 j = new JList01(); 
		j.display();

	}
}