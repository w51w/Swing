package week11A;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;

public class Level extends JFrame{
	Container c;
	JComboBox<String> level;
	int Difficulty;
	JButton submit = new JButton("시작");
	
	public Level() {
		c = getContentPane();
		c.setLayout(new FlowLayout());
		String items[] = new String[10];
		for(int i =0; i<10; i++) {
			items[i] = "" + (i+1);
		}
		
		level = new JComboBox<String>(items);
		c.add(level);	
		c.add(submit);
		
		level.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JComboBox cb = (JComboBox)e.getSource();
				
				int level = cb.getSelectedIndex();
				Difficulty = level+1;
			}
		});
		submit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				TabAndThreadEx ex = new TabAndThreadEx("연타", Difficulty);
			}
		});
	}
	
	void display() {
		setSize(300,300);
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Level l = new Level(); 
		l.display();
	}
	
}
