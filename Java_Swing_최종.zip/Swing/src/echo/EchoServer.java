package echo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class EchoServer {
	ServerSocket serverSocket;
	Socket sock;
	PrintWriter out;
	BufferedReader in;

	public static void main(String[] args) {
		ServerSocket serverSocket = null;
		int port = 4444;
		try {
			serverSocket = new ServerSocket(port);
		}catch(IOException e) { //?제대로 못봄
			System.out.println("connect fail");
			System.exit(0);
		}
		System.out.println("server" + serverSocket.getInetAddress() + "의" + port + "포트에서 연결을 기다림");
		Socket clientSocket = null;
		try {
			clientSocket = serverSocket.accept();
		}catch(IOException e) {
			System.out.println("connect fail");
			System.exit(1);
		}
		try {
			PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
			BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
			String inputLine;
			System.out.println("connect");
			while((inputLine = in.readLine()) != null) {
				if(inputLine.equals("q")) {
					System.exit(0);
				}
				System.out.println(inputLine);
				out.println(inputLine);
			}
			out.close();
			in.close();
			clientSocket.close();
			serverSocket.close();
		}
		catch(IOException e) {
			System.out.println("Disconnected");
		}
	}
}
