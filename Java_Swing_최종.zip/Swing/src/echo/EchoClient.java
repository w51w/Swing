package echo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class EchoClient {

	public static void main(String[] arg) {
		Socket echoSocket = null;
		PrintWriter out = null;
		BufferedReader in = null;
		try {
		//	echoSocket = new Socket(arg[0],Integer.valueOf(arg[1]).intValue());
			echoSocket = new Socket("127.0.0.1", 4444);
			out = new PrintWriter(echoSocket.getOutputStream(),true);
			in = new BufferedReader(new InputStreamReader(echoSocket.getInputStream()));
		}
		catch(UnknownHostException e) {
			System.err.println("호스트가 이상합니다");
			System.exit(1);
		}
		catch(IOException ie) {
			System.err.println("입출력이 이상!");
			System.exit(1);
		}
		try {
			BufferedReader stdIn;
			String userInput;
			stdIn = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Waiting...");
			while((userInput = stdIn.readLine()) != null) {
				out.println(userInput);
				System.out.println("echo :" + in.readLine());
			}
			out.close();
			in.close();
			stdIn.close();
			echoSocket.close();
		}
		catch(Exception e) {
			System.out.println("연결이 끊겼습니다.");
		}
	}
}
